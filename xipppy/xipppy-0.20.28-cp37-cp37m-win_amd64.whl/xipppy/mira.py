"""
mira.py
Copyright Ripple LLC. July 2019
This module provides functionality to ripple MIRA implants and consist of
following classes:
- ImplantFlashCommands: Enum of Flash commands
- MiraIrLedResistorLadderState: create values that can be sent to the implant.
- MiraImplantCmdMode: This is a context manager that enables sending commands
 to a MIRA implant.
"""
import logging
import time

import xipppy
from .exception import XippPyException
from xipppy.transceiver import (
    TransceiverCommand,
    transceiver_command,
    transceiver_power_servo_enable,
    transceiver_set_implant_servo_dac,
    TransceiverStatus,
    TransceiverCmdHeader,
    ImplantRegisterAddrs,
    transceiver_enable_ir_coil,
    DEFAULT_SERVO_DAC_LEVEL,
    IMPLANT_VOLTAGE_STATE
)

MAX_FW_RETRY = 100
FW_PKT_SIZE = 32

M_IMPLANT_CONFIG_ADC = 0x5
M_IMPLANT_CONFIG_ADC_DELAY = 0
M_IMPLANT_CONFIG_DEFAULT_REF = 0xd
M_IMPLANT_CONFIG_LED_MIN = 0x8
M_IMPLANT_CONFIG_LED_LEVEL = 0x8
M_IMPLANT_FLASH_LED_LEVEL_ADR = 0x01

# Minimum waiting time implant needs for each command to take into effect
IMPLANT_CMD_WAITING_TIME = 0.8

logger = logging.getLogger(__name__)


class ImplantFlashCommands:
    ERASE = 0xd0
    READ = 0x40
    SECT_ERASE = 0xe0
    PROG = 0xc0


class MiraIrLedResistorLadderState:
    """
    None of the functions in this class actually send anything to a MIRA
    transceiver or implant. All methods on this class merely create values
    that can be sent to the implant.

    The MIRA implant has two banks of LEDs. Called bank 1 and bank 2.

    Bank 1 has a pair of parallel resistors in series with 2 IR LEDs to regulate
    power. A 2.2 ohm resistor and a 40.2 ohm resistor. If both of these
    resistors are enabled simultaneously then the series resistance is 2 ohms.

    Bank 2 has a pair of parallel resistors in series with 2 IR LEDs to
    regulate power. A 100 ohm resistor and a 150 ohm resistor. If both of these
    resistors are enabled simultaneously then the series resistance is 60 ohms.
    """
    max_power_level = 15

    def __init__(self):
        self._state = 0
        # This is the default power on state for a MIRA.
        self.set_bank_1_2_2_ohm(True)

    def set_all_off(self) -> None:
        """
        If this state were sent to the MIRA transceiver, all LEDs would be off.
        """
        self._state = 0

    def set_bank_1_2_2_ohm(self, enable: bool) -> None:
        """
        If this state were sent to the MIRA transceiver it would set the 2.2
        ohm resistor on LED bank 1.

        :param enable: True for enable, False for disable.
        """
        self.set_bit_state(0b1000, enable)

    def set_bank_1_40_ohm(self, enable: bool) -> None:
        """
        If this state were sent to the MIRA transceiver it would set the 40
        ohm resistor on LED bank 1.

        :param enable: True for enable, False for disable.
        """
        self.set_bit_state(0b0100, enable)

    def set_bank_2_100_ohm(self, enable: bool) -> None:
        """
        If this state were sent to the MIRA transceiver it would set the 100
        ohm resistor on LED bank 2.

        :param enable: True for enable, False for disable.
        """
        self.set_bit_state(0b0010, enable)

    def set_bank_2_150_ohm(self, enable) -> None:
        """
        If this state were sent to the MIRA transceiver it would set the 150
        ohm resistor on LED bank 2.

        :param enable: True for enable, False for disable.
        """
        self.set_bit_state(0b0001, enable)

    def set_bank_1_bank_2_max(self) -> None:
        """
        If this state were sent to the MIRA transceiver it would connect all
        resistors so that the series resistance is minimum for both LED
        banks. This results in the maximum power output for IR LEDs.
        """
        self.set_bank_1_max()
        self.set_bank_2_max()

    def set_bank_1_max(self) -> None:
        """
        If this state were sent to the MIRA transceiver it would connect both
        resistors on bank 1 so that it emits maximum IR LED power.
        """
        self._state |= 0b1100

    def set_bank_2_max(self) -> None:
        """
        If this state were sent to the MIRA transceiver it would connect both
        resistors on bank 2 so that it emits maximum IR LED power.
        """
        self._state |= 0b0011

    def set_bit_state(self, bit, enable):
        """
        If this state were sent to the MIRA transceiver it would set the
        specified 1 hot bit to the specified state. True for on, False for off.

        :param bit: A 1 hot bit that represents where to change the bit state
        in the internal state.
        :param enable: The state to set.
        """
        if enable:
            self._state |= bit
        else:
            self._state &= bit

    def cycle_power_up(self) -> None:
        # The ladder is designed such that the integer value of the binary
        # representation of the ladder state is in sequence of increasing power.
        self._state = divmod(self._state + 1, self.max_power_level + 1)[1]

    def cycle_power_down(self) -> None:
        self._state = divmod(self._state - 1, self.max_power_level + 1)[1]

    def set_power_level(self, level: int) -> None:
        """
        Set the power level from 0 to 15, where 0 is off and 15 has both
        banks turned on with maximum power. Spacing between power levels is
        not uniform. Level is clamped to the range [0, 15]
        """
        self._state = min(max(level, 0), self.max_power_level)

    @property
    def state(self) -> int:
        return self._state


class _MiraImplantCmds:
    """
    This class defines commands that can be sent to a MIRA implant. So browse
    this class to see the documentation for implant commands. The
    peculiar underscore before the class name is there for a reason. It's
    intended to make you ask why, find your way here, and discover the answer.

    The answer is that implant commands cannot be issued to an implant unless
    the implant's coil voltage has been boosted and the servo disabled. After
    commands are completed we need to restore this state to normal operating
    mode. This is achieved by entering a python context that always returns
    an instance of this class that is properly prepared to issue commands.
    For example:

    >>> with MiraImplantCmdMode() as mira_implant:
    >>>     # mira_implant is an instance of _MiraImplantCmds. If you are using
    >>>     # a Pycharm or Jedi this will be detected, and autocomplete will
    >>>     # show a list of implant commands available.
    >>>     mira_implant.set_implant_adc_res_range(6)

    The above example will prep the implant to receive implant commands, issue
    all the implant commands, then reset the transceiver to normal
    mode. Because we are using a context, even if something goes horribly
    wrong within and an exception is thrown, the transceiver state
    will still be properly restored to normal mode.
    """

    def __init__(self, naive_init_guard=True):
        """
        This class must not be directly instantiated unless you are sure you
        have put the implant into command mode yourself. If you have, then
        you can override the guard to disable the RuntimeError. A helpful
        error message is displayed if this is used incorrectly.
        """
        if naive_init_guard:
            raise RuntimeError(
                'To issue commands to a mira implant you must enter a \n'
                'MiraImplantCmdMode context as follows: \n\n'
                'with MiraImplantCmdMode() as mira_implant:'
                '   ...\n\n'
                'You can issue commands to the mira implant by calling methods '
                'on the mira_implant object in the above example within the '
                'context.'

            )
        self.fw_data = None

    max_adc_res = 6
    default_adc_res = M_IMPLANT_CONFIG_ADC
    max_ir_led_output = MiraIrLedResistorLadderState.max_power_level
    _adc_res = M_IMPLANT_CONFIG_ADC
    _adc_delay = M_IMPLANT_CONFIG_ADC_DELAY
    _led_level = M_IMPLANT_CONFIG_LED_LEVEL
    _ref_channel = M_IMPLANT_CONFIG_DEFAULT_REF
    _led_cfg_key = 0

    def set_implant_adc_res_range(self, adc_range: int, elec: int = 0) -> None:
        """
        This function sets the implant recording resolution and range according
        to the following table. Values out of range are clamped to be within
        range.

           Value          uV/bit         Range uV
        --------------------------------------------
           0            0.125          +/- 256
           1            0.25           +/- 512
           2            0.5            +/- 1024
           3            1.0            +/- 2048
           4            2.0            +/- 4096
           5 (default)  4.0            +/- 8192
           6            8.0            +/- 16384
        """
        adc_range = max(min(adc_range, self.max_adc_res), 0)
        cmd = TransceiverCommand(
            TransceiverCmdHeader.IMPLANT_WRITE,
            [0, ImplantRegisterAddrs.RECORDING_RESOLUTION, adc_range]
        )
        transceiver_command(elec, cmd)

    @staticmethod
    def send_implant_wr_cmd(cmd, elec):
        """
        This function sends implant write command for limited times
        and check if that command completed successfully.
        :param cmd: list of integers (MIN_I16 = -32768
        MAX_U16 = 65535) with a data packet size (usually 32)
        command configuration comes from MIRA transceiver/implant firmware spec
        :return: boolean that shows completeness of the command
        """
        completed = False
        timeout_max = 1
        for retry_count in range(timeout_max):
            if not completed:
                xcvr_cmd = TransceiverCommand(
                    TransceiverCmdHeader.IMPLANT_WRITE,
                    cmd)
                transceiver_command(elec, xcvr_cmd)
                # TODO: check for completeness of command
        return completed

    @staticmethod
    def send_implant_rd_cmd(cmd, elec):
        """
        Send implant read command a limited number of times and check if
        that command completed successfully.
        :param cmd: list of integers (MIN_I16 = -32768 MAX_U16 = 65535) with a
        data packet size (usually 32) command configuration comes from MIRA
        transceiver/implant firmware spec
        :return: boolean that shows completeness of the command
        """
        completed = False
        timeout_max = 1
        for retry_count in range(timeout_max):
            if not completed:
                xcvr_cmd = TransceiverCommand(
                    TransceiverCmdHeader.IMPLANT_READ,
                    cmd)
                transceiver_command(elec, xcvr_cmd)
                # TODO: check for completeness of command
        return completed

    def erase_flash(self, elec):
        """
        This function will erase the implant flash at addrss 0x0000 which result
        in whole flash erase.
        """
        erase_cmd = [0xFFFF] * FW_PKT_SIZE
        erase_cmd[0] = 0  # not used
        erase_cmd[1] = 0  # register cmmd
        erase_cmd[2] = 0  # register address
        erase_cmd[3] = ImplantFlashCommands.SECT_ERASE & 0x00FF
        erase_cmd[4] = 0
        self.send_implant_wr_cmd(erase_cmd, elec)

    def program_flash(self, addr_bytes, data, elec):
        """
        This function will write provided data into implant flash at given
        address.
        :param data: list of integers (MIN_I16 = -32768, MAX_U16 = 65535)
        max size shouldn't be more than 32.
        :param addr_bytes: list of 3 flash address bytes
        """
        addr_msb = addr_bytes[0] << 8 | 0x00FF
        addr_lsb = addr_bytes[2] << 8 | addr_bytes[1]
        prog_cmd = [0xFFFF] * FW_PKT_SIZE
        prog_cmd[0] = 0  # not used
        prog_cmd[1] = 0  # register cmmd
        prog_cmd[2] = 0  # register address
        prog_cmd[3] = ImplantFlashCommands.PROG & addr_msb
        prog_cmd[4] = addr_lsb
        for i in range(len(data)):
            prog_cmd[5 + i] = data[i]
        self.send_implant_wr_cmd(prog_cmd, elec)

    def read_flash(self, addr_bytes, elec):
        """
        Read data from implant flash at given address.
        :param addr_bytes: list of 3 flash address bytes
        :return: read data word array
        """
        addr_msb = addr_bytes[0] << 8 | 0x00FF
        addr_lsb = addr_bytes[2] << 8 | addr_bytes[1]
        cmd = [0xFFFF] * FW_PKT_SIZE
        cmd[0] = 0  # not used
        cmd[1] = 0  # register cmmd
        cmd[2] = 0  # register address
        cmd[3] = ImplantFlashCommands.READ & addr_msb
        cmd[4] = addr_lsb
        self.send_implant_rd_cmd(cmd, elec)
        resp = xipppy.transceiver_cmd_response(elec)
        if resp[0] == cmd[3] and resp[1] == cmd[4]:
            return resp[2:]
        raise XippPyException("failed to read from implant flash")

    def get_implant_flash_config(self, elec: int = 0, set_extended_config=False):
        """
        Reads the configuration parameters from flash on the implant.
        Return the following parameters: serial number, R number, FW/HW version,
        ADC resolution, ADC delay, reference channel
        :param elec: Transceiver electrode index
        :param set_extended_config: Flag to indicate if ADC and reference
        parameters read from flash should be saved locally to stage them for the
        next config flash write.
        :return: serial, r_num, fw_hw_ver, adc_res, adc_delay, ref_chan
        """
        data = self.read_flash([0x0, 0x0, 0x0], elec)
        serial = data[0]
        r_num = data[1]
        fw_hw_ver = data[2]
        adc_res = data[3] & 0xf
        adc_delay = data[4] & 0x3ff
        ref_chan = data[5] & 0xf
        if set_extended_config:
            self.set_flash_adc_res(adc_res)
            self.set_flash_adc_delay(adc_delay)
            self.set_flash_ref_channel(ref_chan)
        return serial, r_num, fw_hw_ver, adc_res, adc_delay, ref_chan

    @staticmethod
    def get_status(field, elec: int = 0):
        return xipppy.transceiver_status(elec)[field]

    @staticmethod
    def get_serial_number(elec: int = 0):
        return _MiraImplantCmds.get_status(TransceiverStatus.IMPLANT_SERIAL_NUM,
                                           elec)

    @staticmethod
    def get_r_number(elec: int = 0):
        return _MiraImplantCmds.get_status(TransceiverStatus.IMPLANT_RNUM, elec)

    @staticmethod
    def get_fw_version(elec: int = 0):
        return _MiraImplantCmds.get_status(TransceiverStatus.IMPLANT_FW_HW_VER,
                                           elec)

    @staticmethod
    def reboot(elec: int = 0):
        transceiver_enable_ir_coil(False, elec)
        time.sleep(IMPLANT_CMD_WAITING_TIME)
        transceiver_enable_ir_coil(True, elec)
        transceiver_power_servo_enable(True, elec)
        time.sleep(IMPLANT_CMD_WAITING_TIME)

    @staticmethod
    def set_ref_channel(value, elec: int = 0):
        """
        This will provide the functionality to switch the implant reference.
        it writes provided register value into switchable reference cofiguration
        settig.
        Each device has a unique conversion map between desired ref channel and
        the register value.
        Refer to the implant configuration setting for the map details.

        NOTE: This only works on implants that support switchable references.
        :param value: corresponds to the desired reference channel.
        """
        cmd = TransceiverCommand(
            TransceiverCmdHeader.IMPLANT_WRITE,
            [0, ImplantRegisterAddrs.SW_REF_CONFIG, value]
        )
        transceiver_command(elec, cmd)

    def set_flash_config(self, implant_serial_num, implant_r_num, elec):
        """
        This function will update flash data with provided serial and r numbers
        other flash parameters like fw, hw and adc config will not be changed.
        :param implant_serial_num: Device ID
        :param implant_r_num: Model number
        """
        r_num = implant_r_num if implant_r_num else self.get_r_number(elec)
        fw_version = self.get_fw_version(elec)
        flash_addr_bytes = [0x00] * 3
        flash_data = [0xFFFF] * 6
        flash_data[0] = implant_serial_num
        flash_data[1] = r_num
        flash_data[2] = fw_version
        flash_data[3] = ((self._led_cfg_key & 0xff) << 8) | (self._adc_res & 0x7)
        flash_data[4] = self._adc_delay & 0x3ff
        flash_data[5] = self._ref_channel & 0xf

        self.program_flash(flash_addr_bytes, flash_data, elec)

    def set_flash_adc_res(self, adc_res : int):
        """
        Set and stage flash adc resolution config parameter.
        This setting is not actually written to flash until set_flash_config
        is called.
        :param adc_res: ADC resolution
        """
        self._adc_res = max(min(adc_res, self.max_adc_res), 0)

    def set_flash_adc_delay(self, adc_delay : int):
        """
        Set and stage flash adc delay configuration parameter.
        This setting is not actually written to flash until set_flash_config
        is called.
        :param adc_delay: ADC delay between channel samples
        """
        self._adc_delay = adc_delay

    def set_flash_ref_channel(self, ref_chan : int):
        """
        Set and stage flash reference channel configuration.
        This setting is not actually written to flash until set_flash_config
        is called.
        :param ref_chan: Switchable reference channel
        """
        self._ref_channel = ref_chan

    def set_extended_flash_config(self, adc_res : int = M_IMPLANT_CONFIG_ADC,
            adc_delay : int = M_IMPLANT_CONFIG_ADC_DELAY,
            ref_chan : int = M_IMPLANT_CONFIG_DEFAULT_REF):
        """
        Set and stage extended flash configuration parameters.
        The parameters are not actually written to flash until set_flash_config
        is called.
        :param adc_res: ADC resolution
        :param adc_delay: ADC delay between channel samples
        :param ref_chan: Switchable reference channel
        """
        self.set_flash_adc_res(adc_res)
        self.set_flash_adc_delay(adc_delay)
        self.set_flash_ref_channel(ref_chan)

    def set_led_flash_config(self, led_key : int, led_level : int):
        """
        Set and stage led level configuration parameter in flash.
        The values are not actually written to flash until set_flash_config and
        set_led_level_config is called.
        :param led_key: LED configuration unlock key
        :param led_level: LED light level
        """
        if led_level >= M_IMPLANT_CONFIG_LED_MIN and led_level <= max_ir_led_output:
            self._led_cfg_key = led_key
            self._led_level = led_level

    def set_led_level_config(self, elec: int = 0):
        """
        This function set flash config in a way that will enable future LED
        configuration.
        """
        led_addr_bytes = [0x00] * 3
        led_addr_bytes[1] = M_IMPLANT_FLASH_LED_LEVEL_ADR
        led_data = [M_IMPLANT_CONFIG_LED_LEVEL]
        if self._led_level >= M_IMPLANT_CONFIG_LED_MIN and self._led_cfg_key != 0:
            led_data = [self._led_level]
        self.program_flash(led_addr_bytes, led_data, elec)

    def _set_one_fw_config(self, implant_serial_num,
                           implant_r_num, elec):
        self.erase_flash(elec)
        time.sleep(IMPLANT_CMD_WAITING_TIME)
        self.set_flash_config(implant_serial_num, implant_r_num, elec)
        self.set_led_level_config(elec)
        time.sleep(IMPLANT_CMD_WAITING_TIME)
        self.reboot(elec)
        new_serial = self.get_serial_number(elec)
        logger.debug('Serial# (after re-boot)={}'.format(new_serial))
        if implant_serial_num != new_serial:
            logger.error('Update Serial Failed!')
            return False
        logger.debug('Serial number updated successfully')
        return True

    def update_fw_config(self, implant_serial_num,
                         implant_r_num=None, elec: int = 0):
        """
        This function updates implant config with provided serial and
        model number. Number of commands and their configuration comes from
        MIRA transceiver/implant firmware spec.
        :param implant_serial_num: 4 digit integer device ID
        :param implant_r_num: 4 digit integer model number
        TODO: check for feedback from transceiver
        :return: Boolean shows if the serial number is written successfully.
        """

        # This will change after we can get feedback from command completeness
        timeout_max = 1
        for _ in range(timeout_max):
            if self._set_one_fw_config(implant_serial_num, implant_r_num, elec):
                return True
        return False

    def set_implant_ir_led_output(self, level: int, elec: int = 0) -> None:
        """
        This sets the IR LED led output level on the MIRA implant. Note that
        light levels are not evenly spaced. See documentation for
        MiraIrLedResistorLadderState for a detailed explanation of how the
        output level is controlled.

        NOTE: low light levels WILL cause loss of telemetry. However, because
        this command is issued through the power field, the light can still be
        increased even if telemetry is lost. The level at which telemetry is
        available depends on the medium between the transceiver and implant.

        :param level: A value from 0 to 15 where 0 is off, and 15 is LED output
        maximum. Values outside this range are clamped to be within this range.
        """
        # The following class is just a state manipulator, it has no side
        # effects.
        state = MiraIrLedResistorLadderState()
        state.set_power_level(level)
        cmd = TransceiverCommand(
            TransceiverCmdHeader.IMPLANT_WRITE,
            [0, ImplantRegisterAddrs.LED_PROM_CONFIG, state.state]
        )
        transceiver_command(elec, cmd)


class MiraImplantCmdMode:
    """
    This is a context manager that enables sending commands to a MIRA implant.
    It prepares the transceiver for sending implant commands and returns an
    object with methods that issue commands to the implant; when it is entered
    as a context. See _MiraImplantCmds for an example.

    This context is reentrant. Nesting contexts have no additional effect
    beyond the first. You should only use this within a single thread.

    This context will automatically enter a xipppy_open context. Opening one
    yourself will have no additional effect, but cause no harm. This context
    will receive the use_tcp parameter and pass it on to xipppy_open if it
    xipppy must actually be open. If a tcp xipppy context is already open you
    *do no* need to pass in a matching use_tcp pattern as xipppy is already
    open in tcp mode.
    """
    _user_count = 0

    def __init__(self, elec: int = 0, use_tcp: bool = False):

        self._mira_implant_cmds = None
        self._elec = elec
        self._tcp = use_tcp

    def __enter__(self) -> _MiraImplantCmds:
        self._xp = xipppy.xipppy_open(self._tcp)
        self._xp.__enter__()
        self._mira_implant_cmds = _MiraImplantCmds(
            naive_init_guard=False
        )  # type: _MiraImplantCmds
        if self._user_count == 0:
            self._begin_implant_commands()
        self._user_count += 1
        return self._mira_implant_cmds

    def __exit__(self, exc_type, exc_val, exc_tb):
        if MiraImplantCmdMode._user_count > 0:
            MiraImplantCmdMode._user_count -= 1

        if MiraImplantCmdMode._user_count == 0:
            self._end_implant_commands()
        self._xp.__exit__(exc_type, exc_val, exc_tb)

    def _begin_implant_commands(self):
        # Boost coil voltage and disable power servo to keep this fixed.
        self._boost_coil_voltage()
        transceiver_power_servo_enable(False, self._elec)

    def _end_implant_commands(self):
        # Restore coil voltage to default and enable power servo.
        transceiver_set_implant_servo_dac(
            DEFAULT_SERVO_DAC_LEVEL, self._elec
        )
        transceiver_power_servo_enable(True, self._elec)

    def _boost_coil_voltage(self):
        # This function will boost the implant voltage step by step to over
        # IMPLANT_MINIMUM_BOOST_VOLT (~4.0) so it can be ready for program
        # commands.
        # Servo dac inclement steps are based on experiments.
        for i in range(20, 40, 5):
            transceiver_set_implant_servo_dac(
                DEFAULT_SERVO_DAC_LEVEL + i, self._elec)
            imp_v = xipppy.transceiver_get_implant_voltage(self._elec)
            logger.debug(
                'Boosting implant voltage (imp_v={:.2f})'.format(imp_v))
            if imp_v >= IMPLANT_VOLTAGE_STATE['boosted']:
                return True
            time.sleep(0.33)
        return False
