import array
import ctypes
import itertools
import xipppy_capi as _c

class XippPyException(Exception):
    pass

class XippPyDisconnect(XippPyException):
    pass

#
#  check return values or throw an error for a xipplib call
#  makes the following functions a little smaller
#

def check(n, message="Xipplib call failed"):
    """
    raise a XippPyException if the value n is negative
    """
    if n < 0:
        raise XippPyException(message)
    else:
        return n

def error_string(code):
    msg = array.array('b', itertools.repeat(0, 512))
    (ptr, _) = msg.buffer_info()

    _c.xl_error_string(ptr, len(msg), code)
    return ctypes.string_at(ptr).decode('utf-8')

