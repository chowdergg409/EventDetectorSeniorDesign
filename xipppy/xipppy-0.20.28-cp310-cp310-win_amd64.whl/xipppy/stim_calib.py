import numpy as np

import xipppy_capi as _c
from . import get_fe_version


class IdentityMaps:
    def from_fw(self, fw_chan):
        return fw_chan
    def to_fw(self, chan):
        return chan

class NanoStimMaps:
    NANO_STIM_CHAN_MAP = \
        [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30,
         1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31]
    NANO_STIM_CHAN_MAP_REV = \
        [0, 16, 1, 17, 2, 18, 3, 19, 4, 20, 5, 21, 6, 22, 7, 23,
         8, 24, 9, 25, 10, 26, 11, 27, 12, 28, 13, 29, 14, 30, 15, 31]

    def from_fw(self, fw_chan):
        return self.NANO_STIM_CHAN_MAP_REV[fw_chan]

    def to_fw(self, chan):
        return self.NANO_STIM_CHAN_MAP[chan]


class Pico16StimMaps:
    PICO16_STIM_CHAN_MAP = \
        [30, 0, 28, 2, 26, 4, 24, 6, 22, 8, 20, 10, 18, 12, 16, 14,
         31, 1, 29, 3, 27, 5, 25, 7, 23, 9, 21, 11, 19, 13, 17, 15]
    PICO16_STIM_CHAN_MAP_REV = \
        [1, 17, 3, 19, 5, 21, 7, 23, 9, 25, 11, 27, 13, 29, 15, 31,
         14, 30, 12, 28, 10, 26, 8, 24, 6, 22, 4, 20, 2, 18, 0, 16]

    R_NUMBERS = ['R03026', 'R03824', 'R03027']

    def from_fw(self, fw_chan):
        return self.PICO16_STIM_CHAN_MAP_REV[fw_chan]

    def to_fw(self, chan):
        return self.PICO16_STIM_CHAN_MAP[chan]


def _stim_calib_get_fw_maps_by_rno(r_number):
    """
    get firmware mapys by r_number
    """
    if any(model in r_number for model in Pico16StimMaps.R_NUMBERS):
        return Pico16StimMaps()
    else:
        return NanoStimMaps()

def _stim_calib_get_fw_maps(elec):
    """
    get mapping based on firmware type
    """

    r_number = get_fe_version(elec)
    return _stim_calib_get_fw_maps_by_rno(r_number)


class StimCalib:

    CALIB_DATA_SIZE = 640

    # Provides the mapping from physical electrode to that seen by
    # the ASIC, this is needed for get the trims in the right place

    def __init__(self, fe_id = 0):
        """
        Create a StimCalib
        :param fe_id: either the electrode number idetifying the fe,
                      or a string with the rnumber 'R0....'
                      defaults to fe 0, for automated hardware testing
        """
        self.data = np.zeros(self.CALIB_DATA_SIZE, dtype=np.uint16)
        self.timestamp = np.uint32(0)

        fe_map = None
        if isinstance(fe_id, int):
            fe_map = _stim_calib_get_fw_maps(fe_id)
        elif isinstance(fe_id, str):
            fe_map = _stim_calib_get_fw_maps_by_rno(fe_id)

        if fe_map is None:
            raise ValueError
        else:
            self._map = fe_map

    def chan_to_fw(self, chan):
        return self._map.to_fw(chan)

    def chan_from_fw(self, fw_chan):
        return self._map.from_fw(fw_chan)

    def set_constant_trim(self, val):
        """
        Set all trims to a constant value
        :param val: value to set all trim 0-127
        """
        if val < 0 or val > 127:
            raise ValueError
        up = np.uint16(np.left_shift(val, 8))
        down = np.uint16(val)
        trim = np.bitwise_or(up, down)
        self.data.fill(trim)


    def get_trim(self, pol, res, ampl, elec):
        """
        retrieve trim
        :param pol:
        :param res:
        :param ampl:
        :param elec:
        :return:
        """
        chan = self.chan_to_fw(elec)

        region = int(ampl) // 32
        region_index_map = [1, 1, 0, 0]
        region_index = region_index_map[region]

        index = res * 128 + region_index * 32 + chan
        if not pol:
            index += 64

        if region % 2 == 0:
            return self.data[index] & 0x00ff
        else:
            return (self.data[index] & 0xff00) >> 8


    def get_trim_anode(self, res, ampl, elec):
        """
        return trims for anodic pulses
        :param res: stim resolution (0-4)
        :param ampl: stim amplitude (0-127)
        :param elec: electrode (0-31)
        :return:
        """
        return self.get_trim(1, res, ampl, elec)

    def get_trim_cathode(self, res, ampl, elec):
        """
        return trim value for cathodic pules
        :param res: stim resolution (0-4)
        :param ampl: stim amplitude (0-127)
        :param elec: electrode to (0-31)
        :return:
        """
        return self.get_trim(0, res, ampl, elec)


    def set_trim(self, pol, res, ampl, elec, val):
        if res < 0 or res > 4:
            raise ValueError
        if ampl < 0 or ampl > 127:
            raise ValueError
        if elec < 0 or elec > 31:
            raise ValueError
        if val < 0 or val > 127:
            raise ValueError

        chan = self.chan_to_fw(elec)
        region = int(ampl) // 32
        region_index_map = [1, 1, 0, 0]
        region_index = region_index_map[region]

        index = res * 128 + region_index * 32 + chan
        if not pol:
            index += 64

        if region % 2 == 0:
            bak = self.data[index] & 0xff00
        else:
            bak = self.data[index] & 0x00ff
            val <<= 8

        self.data[index] = bak | val


    def set_trim_anode(self, res, ampl, elec, val):
        """
        Set trim for specific region for an anodic pulse
        :param res: stim resolution (0-4)
        :param ampl: stim amplitude (0-127)
        :param elec: electrode to set
        :param val: trim value (0-127)
        """
        self.set_trim(1, res, ampl, elec, val)

    def set_trim_cathode(self, res, ampl, elec, val):
        """
        Set trim for specific region for an cathodic pulse
        :param res: stim resolution (0-4)
        :param ampl: stim amplitude (0-127)
        :param elec: electrode to set
        :param val: trim value (0-127)
        """
        self.set_trim(0, res, ampl, elec, val)


    def get_pos_trim_by_fw_index(self, fw_index):
        """
        Return the trim by the index used in the firmware as
        uint16's (so contains two trims).  There will be 320
        for neg and positive each.
        """
        chan = fw_index % 32
        elec = self.chan_from_fw(chan)
        res = int(fw_index / 64) % 5
        sec = int(fw_index / 32) % 2

        if sec == 0:
            val_high = self.get_trim_anode(res, 120, elec)
            val_low = self.get_trim_anode(res, 75, elec)
        else:
            val_high = self.get_trim_anode(res, 50, elec)
            val_low = self.get_trim_anode(res, 20, elec)

        assert (val_high < 128)
        assert (val_low < 128)
        return (val_high << 8) | val_low


    def get_neg_trim_by_fw_index(self, fw_index):
        """
        Return the trim by the index used in the firmware as
        uint16's (so contains two trims).  There will be 320
        for neg and positive each.
        """
        chan = fw_index % 32
        elec = self.chan_from_fw(chan)

        res = int(fw_index / 64) % 5
        sec = int(fw_index / 32) % 2
        if sec == 0:
            val_high = self.get_trim_cathode(res, 120, elec)
            val_low = self.get_trim_cathode(res, 75, elec)
        else:
            val_high = self.get_trim_cathode(res, 50, elec)
            val_low = self.get_trim_cathode(res, 20, elec)
        assert (val_high < 128)
        assert (val_low < 128)

        return (val_high << 8) | val_low




def stim_calib_get(elec):
    """
    return current calibration table for electrode

    :param elec: desired electrode (0 indexed)
    """

    raw = _c.xl_stim_calib_get(elec)
    if raw is None:
        return None

    out = StimCalib(elec)
    out.timestamp = raw.timestamp
    out.data = np.array(raw.data, dtype=np.uint16)
    return out

def stim_calib_set(elec, calib):
    if not isinstance(calib, StimCalib):
        raise TypeError('calib parameter must be an instance of StimCalib')

    new_calib = _c.XippCalib_t()
    new_calib.timestamp = int(calib.timestamp)
    new_calib.data = [ int(x) for x in calib.data ]
    _c.xl_stim_calib_set(elec, new_calib)

def stim_calib_start(elec):
    _c.xl_stim_calib_start(elec)

