import ctypes

import xipppy_capi as _c

from .exception import XippPyException
from .exception import check


class Sensor:
    def __init__(self, other=None):
        if not other:
            self.current = 0.0
            self.voltage = 0.0
            self.power = 0.0
        else:
            self.current = other.current
            self.voltage = other.voltage
            self.power = other.power


def internal_battery():
    res = ctypes.c_int(0)
    check(_c.xl_internal_battery(ctypes.addressof(res)))
    return res.value


def wall_sensor():
    res = _c.XippSensor_t()
    check(_c.xl_wall_sensor(res))
    return Sensor(res)


def vdd_sensor():
    res = _c.XippSensor_t()
    check(_c.xl_vdd_sensor(res))
    return Sensor(res)


def external_battery_detected():
    res = ctypes.c_int(-1)
    check(_c.xl_external_battery_detected(ctypes.addressof(res)))
    if res.value < 0:
        raise XippPyException("Error detecting external battery")
    return bool(res.value)

def external_battery():
    res = ctypes.c_int(0)
    check(_c.xl_external_battery(ctypes.addressof(res)))
    return res.value

