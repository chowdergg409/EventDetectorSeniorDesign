import array
import ctypes
import itertools

import xipppy_capi as _c
from .exception import check


def fast_settle_get_choices(fe, fs_type, max_names=32):
    """
    Get options for fast settle for front end fe

    Arguments:
        fe: front end id 0-15
        fs_type: 'stim' or 'digin'
        max_names: maximum number of type strings to output. Any more than this
                 number will be truncated.
    """
    data = array.array('b', itertools.repeat(0, max_names * _c.STRLEN_LABEL))
    (ptr, _) = data.buffer_info()

    cur = array.array('i', [0])
    (cur_ptr, _) = cur.buffer_info()

    n = check(_c.xl_fast_settle_get_choices(
        fe, fs_type, ptr, max_names, cur_ptr),
        "Error getting fast settle choices for {}".format(fe))
    ret = []
    for i in range(n):
        addr = ptr + i * _c.STRLEN_LABEL
        s = ctypes.string_at(addr)
        ret.append(s.decode('utf-8'))

    return cur[0], ret


def fast_settle_get_duration(fe, fs_type):
    """
    Get duration for fast settle

    Arguments:
        fe: front end id 0-15
        fs_type: 'stim' or 'digin'

    """
    data = array.array('f', [0.0])
    (ptr, _) = data.buffer_info()

    check(_c.xl_fast_settle_get_duration(fe, fs_type, ptr),
          "Error getting fast settle choices for {}".format(fe))

    return data[0]


def fast_settle(fe, fs_type, item=None, duration=None):
    """
    Set fast settle for front end fe

    Arguments:
        fe: front end id 0-15
        fs_type: 'stim' or 'digin'
        item: index of fast settle option or None for default
        duration: fas settle duration or none for default
    """

    if item is not None:
        item_space = array.array('i', [item])
        (item_ptr, _) = item_space.buffer_info()
    else:
        item_ptr = 0

    if duration is not None:
        dur_space = array.array('f', [duration])
        (dur_ptr, _) = dur_space.buffer_info()
    else:
        dur_ptr = 0

    check(_c.xl_fast_settle(fe, fs_type, item_ptr, dur_ptr))
